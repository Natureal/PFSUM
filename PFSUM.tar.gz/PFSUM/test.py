import datetime

print(1 / 3)
